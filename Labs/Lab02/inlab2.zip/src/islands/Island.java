package islands;
import java.util.ArrayList;

public class Island {

   private final ArrayList<Cell> cells = null;

   public Island() {
     // TODO
   }

   public Island(Cell cell) {
       // TODO
   }

   public void merge(Island island) {
       //TODO
   }
   public int size() {
       //TODO
       return 0;
   }

   public boolean hasCell(Coordinates coordinates) {
       // TODO
       return false;
   }
   public void addCell(Cell cell) {
       // TODO
   }

   public boolean touchesBoardBoundaries(int rows, int cols, Direction direction) {
       // TODO
       return false;
   }

   @Override
   public boolean equals(Object other) {
       // TODO
       return false;
   }

   @Override
   public String toString() {
       return null;
   }
 }